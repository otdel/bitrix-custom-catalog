<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/yandex_simple_setup.php");
?>