<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/froogle_util.php");
?>