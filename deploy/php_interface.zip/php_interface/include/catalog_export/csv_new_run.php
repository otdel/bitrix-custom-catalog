<?
//<title>Export CSV (new)</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/csv_new_run.php");
?>