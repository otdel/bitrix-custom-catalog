<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/csv_new_setup.php");
?>