<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load_import/csv_new_setup.php");
?>