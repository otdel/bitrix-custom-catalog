<?
$MESS ['news_template_name'] = "Дайджест новостей";
$MESS ['news_template_desc'] = "Шаблон генерации дайджеста новостей.";
?>